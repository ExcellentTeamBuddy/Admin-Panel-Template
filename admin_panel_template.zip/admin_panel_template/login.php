<?php 
  include_once(__DIR__ .'/templates/includes/header.php'); 
?>
    <div>      
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container-login">
          <div class="card ">

            <div class="card-header text-center my-card-header">
              <h1>Login</h1>
            </div>

            <div class="card-body">

              <div class="login-box" align="center">                
                <form method="post" action="" name="loginFrm" id="loginFrm">
                  <div class="form-group mb-3">
                    <input type="email" class="form-control" placeholder="Email" name="email" id="email">                        
                  </div>
                  <div class="form-group mb-3">
                    <input type="password" class="form-control" placeholder="Password" name="password" id="password">
                  </div>
                  <div class="row">
                    <div class="col-12">
                      <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                    </div>
                  </div>
                </form>
              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->
    </div>
<?php 
  include_once(__DIR__ .'/templates/includes/footer.php'); 
?>