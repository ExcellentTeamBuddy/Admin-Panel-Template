		<div class="modal fade" id="modal-primary">
	        <div class="modal-dialog">
	        	
	        	<form method="post" action="" name="loginFrm" id="loginFrm">

		          <div class="modal-content">
		            <div class="modal-header">
		              <h4 class="modal-title">Add Product</h4>
		              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                <span aria-hidden="true">&times;</span>
		              </button>
		            </div>
	            
		            <div class="modal-body">

	                  <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="name" id="name">
                      </div>

	                  <div class="form-group">
                        <label>Price</label>
                        <input type="text" class="form-control" name="price" id="price">
                      </div>

	                  <div class="form-group">
                        <label>Quantity</label>
                        <input type="text" class="form-control" name="qty" id="qty">
                      </div>

	                  <div class="form-group">
                        <label>Textarea</label>
                        <textarea class="form-control" rows="3" name="description" id="description"></textarea>
                      </div>	                  	                

		            </div>
		            <div class="modal-footer float-right">
		              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		              <button type="button" class="btn btn-primary">Submit</button>
		            </div>
	            
		          </div>
		          <!-- /.modal-content -->
	          </form>
	        </div>
	        <!-- /.modal-dialog -->
	    </div>
	    <!-- /.modal -->

		<!-- jQuery -->
	    <script src="assets/plugins/jquery/jquery.min.js"></script>

	    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

	    <!-- DataTables  & Plugins -->
	    <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
	    <script src="assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	    <script src="assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	    <script src="assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>	    

	    <script>
	    	$( document ).ready(function() {
	    		$(document).on("click",".btn-group__item",function(e){
				    window.location.href = $(this).attr('data-url');
				});
			});
		    $(function () {        
		        $('#example2').DataTable({
		          "paging": true,
		          "lengthChange": false,
		          "searching": true,
		          "ordering": true,
		          "info": true,
		          "autoWidth": false,
		          "responsive": true,
		        });
		    });
	    </script>

	</body>
</html>