		<nav class="navbar">
	        <div class="btn-group">	          
				<button class="btn-group__item" data-url="dashboard.php">Dashboard</button>
				<button class="btn-group__item" data-url="order.php">Orders</button>
				<button class="btn-group__item" data-url="product.php">Products</button>
				<button class="btn-group__item" data-url="user.php">Users</button>
				<button class="btn-group__item" data-url="login.php">Logout</button>	            
	        </div>
	    </nav>