<?php 
  include_once(__DIR__ .'/templates/includes/header.php'); 
?>
    <div>
      <?php 
        include_once(__DIR__ .'/templates/includes/navbar.php'); 
      ?>
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container">
          <div class="card">

            <div class="card-header my-card-header">
              <div class="row">
                <div class="col-6">
                  <h4>Product Lists</h4>
                </div>
                <div class="col-6">
                  <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-primary">Add Product</button>
                </div>
              </div>              
            </div>           

            <div class="card-body">

              <div class="login-box" align="center">                
                <table id="example2" class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Quantity</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div class="my-product-image-thumb dt-product-width">
                          <img src="assets/images/Gulab Supreme Refined Soyabean 15 Ltr - Jar.png" alt="">
                        </div>
                      </td>
                      <td><a href="product_details.php">Gulab Supreme Refined Soyabean : 15 Liters</a></td>
                      <td>2350</td>
                      <td>10</td>
                      <td>
                        <div class="DTdivSwitch">
                          <label class="toggleSwitch toggleSwitchSM">
                            <input type="checkbox" class="toggleChangeStatus" checked>
                            <span class="toggleSlider toggleSliderSM roundtoggle"></span>
                          </label>
                        </div>
                      </td>
                      <td>
                        <div>                
                          <a href="javascript:void(0)" class="myNavLink">
                            <i class="fas fa-eye mr-2"></i>
                          </a>
                          <a href="javascript:void(0)" class="myNavLink">
                            <i class="fas fa-edit mr-2"></i>
                          </a>
                          <a href="javascript:void(0)" class="myNavLink">
                            <i class="fas fa-trash-alt mr-2"></i>
                          </a>                        
                        </div>                      
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->      

    </div>    

<?php 
  include_once(__DIR__ .'/templates/includes/footer.php'); 
?>