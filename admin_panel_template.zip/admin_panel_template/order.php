<?php 
  include_once(__DIR__ .'/templates/includes/header.php'); 
?>
    <div>
      <?php 
        include_once(__DIR__ .'/templates/includes/navbar.php'); 
      ?>
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container">
          <div class="card">

            <div class="card-header my-card-header">
              <div class="row">
                <div class="col-6">
                  <h4>Order Lists</h4>
                </div>
                <!-- <div class="col-6">
                  <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-primary">Order User</button>
                </div> -->
              </div>              
            </div>           

            <div class="card-body">

              <div class="login-box" align="center">                
                <table id="example2" class="table table-bordered">
                  <thead>
                    <tr>
                      <th>User Name</th>
                      <th>Order No</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>                    
                      <td>John Smith</td>
                      <td><a href="order_details.php">OD1234567890</a></td>
                      <td>
                        <div>                
                          <a href="javascript:void(0)" class="myNavLink">
                            <i class="fas fa-eye mr-2"></i>
                          </a>
                          <a href="javascript:void(0)" class="myNavLink">
                            <i class="fas fa-edit mr-2"></i>
                          </a>
                          <a href="javascript:void(0)" class="myNavLink">
                            <i class="fas fa-trash-alt mr-2"></i>
                          </a>                        
                        </div>                      
                      </td>
                    </tr>
                  </tbody>
                </table>

              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->      

    </div>    

<?php 
  include_once(__DIR__ .'/templates/includes/footer.php');
?>