<?php 
  include_once(__DIR__ .'/templates/includes/header.php'); 
?>
    <div>
      <?php 
        include_once(__DIR__ .'/templates/includes/navbar.php'); 
      ?>
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container">
          <div class="card ">           

            <div class="card-body">

              <div class="login-box" align="center">                
                <h1>Welcome To Admin Panel</h1>
              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->
    </div>
<?php 
  include_once(__DIR__ .'/templates/includes/footer.php'); 
?>